# Gas_CaseStudy
Django application to provide consumer services for gas utilities

Landing page : 

![Screenshot (150)](https://github.com/ttk4001/Gas_CaseStudy/assets/115856620/cfb8d495-1d30-4f72-959b-4811f501bdbd)

 Signup Page :
 
![Screenshot (151)](https://github.com/ttk4001/Gas_CaseStudy/assets/115856620/b09ab5e5-62f1-45bf-8591-10d3ccfa1e88)

Home Page :

![Screenshot (152)](https://github.com/ttk4001/Gas_CaseStudy/assets/115856620/8359514f-80d5-4314-b2b6-0ac7b422296f)

Submit Request Page :

![Screenshot (153)](https://github.com/ttk4001/Gas_CaseStudy/assets/115856620/3aa07dea-4a11-4dd1-8ebc-9b815b45194a)

Request Status Tracking :

![Screenshot (154)](https://github.com/ttk4001/Gas_CaseStudy/assets/115856620/ca512eaa-6a2c-451e-95be-6aaaea834bf4)

Customer Support :

![Screenshot (155)](https://github.com/ttk4001/Gas_CaseStudy/assets/115856620/b57b60b7-9bbb-4ed8-a1f1-dcb9adb6564b)

Database :
![Screenshot (156)](https://github.com/ttk4001/Gas_CaseStudy/assets/115856620/4416930a-701c-4b15-ab3b-33e6935895fd)








